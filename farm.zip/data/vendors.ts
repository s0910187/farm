import { Vendor } from '../types';

export const INITIAL_VENDORS: Vendor[] = [];
